#include "TaxableProduct.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;
TaxableProduct::TaxableProduct(int productID,
                            const string& name,
                            double price,
                            int stock,
                            double taxRate)
    : Product(productID, name, price, stock), taxRate(taxRate){
    if (taxRate < 0.0)
        throw invalid_argument("Tax rate cannot be negative.");
}
double TaxableProduct::calculateFinalPrice() const {
    return getPrice() * (1 + taxRate);
}
void TaxableProduct::displayProduct() const {
    Product::displayProduct();
    cout <<"| Tax Rate: " << taxRate * 100 << "%"
        <<"| Final Price: R" << calculateFinalPrice() << endl;
}
