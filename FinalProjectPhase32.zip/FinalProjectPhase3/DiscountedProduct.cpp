#include "DiscountedProduct.h"
#include <iostream>
#include <stdexcept>
using namespace std;
// Parameterized constructor
DiscountedProduct::DiscountedProduct(int productID,
                                const string& name,
                                double price,
                                int stock,
                                double discountRate)
        : Product(productID, name, price, stock), discountRate(discountRate){
    if (discountRate < 0.0)
        throw invalid_argument("Discount rate cannot be negative.");
}
double DiscountedProduct::calculateFinalPrice() const {
    return getPrice() * (1 - discountRate);
}
void DiscountedProduct::displayProduct() const {
    Product::displayProduct();
    cout << "| Discount Rate: " << discountRate * 100 << "%"
        << "| Final Price: R" << calculateFinalPrice() << endl;
}
