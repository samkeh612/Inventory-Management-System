#include <iostream>
#include "Menu.h"

using namespace std;
int main() {

    Menu menu;
    menu.startingPoint();

    return 0;
}
