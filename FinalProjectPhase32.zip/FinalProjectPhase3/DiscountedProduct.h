#ifndef DISCOUNTEDPRODUCT_H
#define DISCOUNTEDPRODUCT_H
#include "Product.h"
class DiscountedProduct : public Product {
private:
    double discountRate;
public:
    DiscountedProduct(int productID,
        const std::string& name,
        double price,
        int stock,
        double discountRate);
    double calculateFinalPrice() const override;
    void displayProduct() const override;
};
#endif
