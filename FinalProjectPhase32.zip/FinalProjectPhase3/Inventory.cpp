#include "Inventory.h"
#include <iostream>
#include <algorithm>
using namespace std;
Inventory::Inventory() {}
//Add new product
bool Inventory::addProduct(shared_ptr<Product> product){
    lock_guard<mutex> lock(inventoryMutex);
    int id = product->getProductID();
    if (products.find(id) != products.end()) {
        return false;
    }
    products[id] = product;
    return true;
}
//Remove Product
bool Inventory::removeProduct(int productID){
    lock_guard<mutex> lock(inventoryMutex);
    return products.erase(productID) > 0;
}
//Search Product
shared_ptr<Product> Inventory::searchProductByID(int productID) const {
    lock_guard<mutex> lock(inventoryMutex);
    auto it = products.find(productID);
    if (it != products.end()) {
        return it->second;
    }
    return nullptr;
}
//Display all products in map
void Inventory::displayAllProducts() const{
    lock_guard<mutex> lock(inventoryMutex);
    for (const auto& pair : products){
        pair.second->displayProduct();
        cout << "---------------------------------------------------------------------------------------------------------------------------------------" << endl;
    }
}
//Display product sorted by price
void Inventory::displaySorted() const {
    auto sortedProducts=sortByPrice();
    for (const auto& product : sortedProducts) {
        product->displayProduct();
        cout << "---------------------------------------------------------------------------------------------------------------------------------------" << endl;
    }
}
//Sort products by price
vector<shared_ptr<Product>> Inventory::sortByPrice() const{
    lock_guard<mutex> lock(inventoryMutex);
    vector<shared_ptr<Product>> sortedProducts;
    for (const auto& pair : products){
        sortedProducts.push_back(pair.second);
    }
    sort(sortedProducts.begin(), sortedProducts.end(),
        [](const shared_ptr<Product>& a,const shared_ptr<Product>& b){
            return a->getPrice() < b->getPrice();
        });
    return sortedProducts;
}
//Process order 
void Inventory::processOrder(Order& order){
    lock_guard<mutex> lock(inventoryMutex);
    //ProductID from product
    auto it = products.find(order.getProductID());
    auto product = it->second;

    product->reduceStock(order.getQuantity());
    order.setOrderStatus(SUCCESS);
    order.setFailedReason(NONE);
    
    //not found
    if (it==products.end()) {
        order.setOrderStatus(FAILED);
        order.setFailedReason(PRODUCT_NOT_FOUND);
        return;
    }
    if (product-> getStock() < order.getQuantity()) {
        order.setOrderStatus(FAILED);
        order.setFailedReason(INSUFFICIENT_STOCK);
        return;
    }
}