#ifndef INVENTORY_H
#define INVENTORY_H

#include <map>
#include <memory>
#include <vector>
#include <mutex>

#include "Order.h"
#include "Product.h"
class Inventory {
private:
    // Map storing Product objects using shared_ptr
    std::map<int, std::shared_ptr<Product>> products;
    // Mutex for thread safety
    mutable std::mutex inventoryMutex;
public:
    Inventory();
    bool addProduct(std::shared_ptr<Product> product);
    bool removeProduct(int productID);
    std::shared_ptr<Product> searchProductByID(int productID) const;
    void displayAllProducts() const;
    std::vector<std::shared_ptr<Product>> sortByPrice() const;
    void displaySorted() const;
    // Process order (reduce stock safely)
    void processOrder(Order& order);
};

#endif
