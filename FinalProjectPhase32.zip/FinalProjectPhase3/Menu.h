#ifndef MENU_H
#define MENU_H
#include <vector>
#include "Inventory.h"
#include "Order.h"

class Menu{
public:
    Menu(); 
    void displayProduct(Inventory& inventory);
    void takeOrder(Inventory& inventory, std::vector<Order>& orders);
    void viewOrder(std::vector<Order>& orders);
    void searchProductByID(Inventory& inventory);
    // Management functions
    void addNewProduct(Inventory& inventory);
    void removeProduct(Inventory& inventory);
    void restockProduct(Inventory& inventory);
    void sortByPrice(Inventory& inventory);
    void processOrder(Inventory& inventory, vector<vector<Order>>& orders);
    bool idExists(vector<Order>& orders, int orderID);
    Inventory& fillInventory(Inventory& inventory);
    void setOrders(vector<vector<Order>>& orders);
    void CustomerInterface(Inventory& inventory, vector<vector<Order>>& orders);
    void ManagementInterface(Inventory& inventory, vector<vector<Order>>& orders);
    // Main menu entry point
    void startingPoint();
};
#endif