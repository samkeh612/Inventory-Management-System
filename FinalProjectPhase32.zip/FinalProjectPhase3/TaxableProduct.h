#ifndef TAXABLEPRODUCT_H
#define TAXABLEPRODUCT_H
#include <string>
#include "Product.h"
using namespace std;

class TaxableProduct : public Product {
private:
    double taxRate;
public:
    TaxableProduct(int id, const string& name, double price, int stock, double taxRate);
    double calculateFinalPrice() const override;
    void displayProduct() const override;
};
#endif
