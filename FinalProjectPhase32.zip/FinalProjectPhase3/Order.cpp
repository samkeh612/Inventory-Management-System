#include "Order.h"
#include <iostream>
using namespace std;
Order::Order(int orderID,int productID,int quantity):
    orderID(orderID),productID(productID),quantity(quantity),orderStatus(PENDING){}
status Order:: getOrderStatus() const {
    return orderStatus;
}
void Order:: setOrderStatus(status newStatus) {
    orderStatus = newStatus;
}
reason Order::getFailedReason() const {
    return FailedReason;
}
void Order::setFailedReason(reason newReason) {
    FailedReason = newReason;
}
int Order::getProductID() const{
    return productID;
}
int Order::getQuantity() const{
    return quantity;
}
int Order::getOrderID() const {
    return orderID;
}
string Order::statusToString(status newStatus) const {
    switch(newStatus) {
        case PENDING:return "PENDING";
        case SUCCESS:return "SUCCESS";
        case FAILED:return "FAILED";
        default: return "UNKNOWN";
    }
}
string Order::reasonToString(reason newReason) const{
    switch(newReason) {
        case PRODUCT_NOT_FOUND: return "PRODUCT NOT FOUND";
        case INSUFFICIENT_STOCK: return "INSUFFICIENT STOCK";
        case NONE:return "ORDER WAS SUCCESSFUL";
        default: return "UNKNOWN";
    }
}
void Order::displayOrder() const{
    cout<<"Order ID: "<<getOrderID()
        << "| Status: " << statusToString(getOrderStatus());
    if(getOrderStatus() == FAILED) {
        cout << " (" << reasonToString(getFailedReason()) << ")";
    }
    cout << endl;
}
