#ifndef PRODUCT_H
#define PRODUCT_H
#include <string>
#include <iostream>
class Product {
private:
    int productID;
    int stock; 
    std::string name;
protected:
    double price;
public:
    Product(int productID, const std::string& name, double price, int stock);
    int getStock() const;
    double getPrice() const;
    int getProductID() const;
    const std::string& getName() const;
    void reduceStock(int amount);
    void increaseStock(int amount);
    virtual void displayProduct() const;
    virtual double calculateFinalPrice() const = 0;
    virtual ~Product();
};
#endif