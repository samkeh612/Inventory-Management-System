#include <iostream>
#include <thread>
#include <vector>
#include <functional>
#include <memory>
#include <algorithm>
#include <fstream>
#include <string>
#include <mutex>
#include "Menu.h"
#include "Inventory.h"
#include "Order.h"
#include "TaxableProduct.h"
#include "DiscountedProduct.h"
using namespace std;
std::mutex inventoryMutex;
bool loginUser();
bool usernameExists(const string& username){
    ifstream file("users.txt");
    string user, pass;

    while(file >> user>> pass){
        if(user == username){
            return true;
        }
    }
    return false;
}
void registerUser() {
    ofstream file("users.txt", ios::app);
    string username, password;

    cout << "Enter new username: ";
    cin >> username;
    
    if (usernameExists(username)){
        cout<< "Username already exist. Log in: \n";
        loginUser();
        return;
    }

    while(true){
        //cout << "Password must be atleast 8 characters and contain at least one of (@, !, &). \n";
        cout << "Enter password: ";
        cin >> password;
        
        bool specialCharacter = false;
        for (char character:password){
            if (character =='@' || character == '!' ||character=='&'){
                specialCharacter = true;
                break;
            }
        }
        if(password.length()>8 && specialCharacter){
            break;
        }else{
            cout << "Password must be atleast 8 characters and contain at least one of (@, !, &). Try Again. \n";
        }
    }


    file << username << " " << password << endl;
    file.close();

    cout << "Registration successful" << endl;
}
bool loginUser() {
    ifstream file("users.txt");
    string username, password, fileUser, filePass;
    int choice4;

    cout << "Enter username: ";
    cin >> username;

    //cout << "Password must be atleast 8 characters and contain at least one of (@, !, &). \n";
    cout << "Enter password: ";
    cin >> password;

    bool userFound = false;

    while (file >> fileUser >> filePass) {

        if (fileUser == username) {
            userFound = true;

            if (filePass == password) {
                cout << "Login successful\n";
                return true;
            }

            cout << "Wrong password.\n";

            while (true) {
                cout << "1. Try again\n";
                cout << "0. Forgot password \n";
                cin >> choice4;

                if (choice4 == 1) {
                    cout << "Enter password again: ";
                    cin >> password;

                    if (password == filePass) {
                        cout << "Login successful \n";
                        return true;
                    } else {
                        cout << "Wrong password. \n";
                    }

                } else if (choice4 == 0) {
                    registerUser();
                    return false;
                }
            }
        }
    }

    if (!userFound) {
        cout << "User not found. Please register.\n";
        registerUser();
    }

    return false;
}
bool Log(){
    int choice;
    bool loggedIn = false;

    cout << "1. Register\n2. Login\nChoice: ";
    cin >> choice;

    if (choice == 1) {
        registerUser();
        loggedIn = true;
        return loggedIn;
    }else if(choice == 2){
        loggedIn = loginUser();
        return loggedIn;
    }else{
        if(!loggedIn){
        cout << "Exiting program...\n";
        return false;
        }
    }
    return false;
}
Menu:: Menu(){}
/* -------------------- WORKER FUNCTION -------------------- */
void worker(Inventory& inventory, Order& order) {
    std::lock_guard<std::mutex> lock(inventoryMutex);
    inventory.processOrder(order);
}
void Menu::processOrder(Inventory& inventory, vector<vector<Order>>& orders) {
    cout << "\n______________________Processing Orders___________________________\n";
    if (orders.empty()) {
        cout << "There are no orders to process!" << endl;
        return;
    }
    const int TotalOrderNum = 20;
    vector<thread> threads;
    int processedCount = 0;
    // loop through all customer order groups
    for (auto& customerOrders : orders) {
        // loop through each order in customer group
        for (auto& order : customerOrders) {
            if (processedCount >= TotalOrderNum) {
                break;
            }
            threads.emplace_back(worker, ref(inventory), ref(order));
            processedCount++;
        }
        if (processedCount >= TotalOrderNum) {
            break;
        }
    }
    // join all threads
    for (auto& t : threads) {
        t.join();
    }
    cout << "\n========================= ORDER RESULTS =========================\n";
    // display all processed orders
    for (auto& customerOrders : orders) {

        for (auto& order : customerOrders) {
            order.displayOrder();
        }
    }
    cout << "_________________________________________________________________\n";
}
void Menu::startingPoint() {
    Inventory inventory;
    vector<vector<Order>> orders;
    setOrders(orders);
    fillInventory(inventory);
    int choice;
    while (true) {
        cout << "\n================ INVENTORY MANAGEMENT ================\n";
        cout << "Please Sign in as Customer or Management:\n";
        cout << "1. Customer\n";
        cout << "2. Management\n";
        cout << "3. Exit\n";
        cout << "Choice: ";
        cin >> choice;
        if(choice == 1) {
            cout << "\n================= Hi Valued Customer ==================\n";
            if (Log()) {
                CustomerInterface(inventory, orders);
            }
        }
        else if (choice == 2) {
            cout << "\n================== Welcome Management ==================\n";
            if (Log()) {
                ManagementInterface(inventory, orders);
            }
        }
        else if (choice == 3) {
            cout << "Exiting program...\n";
            return;
        }
        else {
            cout << "Invalid choice.\n";
        }
    }
}
void Menu::addNewProduct(Inventory& inventory) {
    cout<<"\n________________________Add New Product__________________________\n";
    int choice;
    cout<<"Product Type"<<endl;
    do {
        cout<<"1. Taxable"<<endl;
        cout<<"2. Discounted"<<endl;
        cout<<"Choice: ";
        cin>>choice;
    }while (choice!=1 && choice!=2);
    int ID,stock;
    double price,rate;
    string name;
    cout<<"Enter product name: ";
    cin>>name;
    cout<<"Enter product ID: ";
    cin>>ID;
    while (inventory.searchProductByID(ID)) {
        cout << "ID already exists! Enter a different ID: ";
        cin >> ID;
    }
    do {
        cout << "Price: R";
        cin >> price;
        if(price <= 0) {
            cout << "Price must be greater than 0!" << endl;
        }
    } while(price <= 0);
    do {
        cout << "Stock quantity: ";
        cin >> stock;
        if(stock <= 0) {
            cout << "Stock must be greater than 0!" << endl;
        }
    } while(stock <= 0);
    string rateType = (choice == 1) ? "tax" : "discount";

    do {
        cout << "Enter " << rateType << " rate (0.00 to 1.00): ";
        cin >> rate;
        if(rate < 0 || rate > 1) {
            cout << "Rate must be between 0.0 and 1.0!" << endl;
        }
    } while(rate < 0 || rate > 1);
    if (choice==1) {
        inventory.addProduct(make_shared<TaxableProduct>(ID,name,price,stock,rate));
    }else {
        inventory.addProduct(make_shared<DiscountedProduct>(ID,name,price,stock,rate));
    }
    cout<<name<<" added Successfully!"<<endl;
    cout<<"______________________________________________________________________________________________________________________________________\n";
}
void Menu::removeProduct(Inventory& inventory) {
    int ID;
    cout<<"________________________Remove Product________________________________________________________________________________________________\n";
    cout<<"Enter product ID: ";
    cin>>ID;
    if (inventory.searchProductByID(ID)) {
        inventory.removeProduct(ID);
        cout<<"Product removed successfully!!"<<endl;
    }else {
        cout << "Product ID " << ID << " does not exist!" << endl;
    }
    cout<<"\n_____________________________________________________________________________________________________________________________________\n";
}
void Menu::displayProduct(Inventory &inventory) {
    cout<<"\n_____________________Inventory Products__________________________\n";
    inventory.displayAllProducts();
    cout<<"_________________________________________________________________\n";
}
void Menu::restockProduct(Inventory &inventory) {
    cout<<"\n_______________________Restock Product___________________________\n";
    int ID;
    cout<<"Enter product ID: ";
    cin>>ID;
    if (!inventory.searchProductByID(ID)) {
        cout<<"Product does not exist!"<<endl;
    }else {
        auto product= inventory.searchProductByID(ID);
        int stock;
        do {
            cout << "Enter stock quantity: ";
            cin >> stock;
            if(stock <= 0) {
                cout <<"Stock must be greater than 0!" << endl;
            }
        } while(stock <= 0);
        product->increaseStock(stock);
        cout<<product->getName()<<" restocked Successfully!"<<endl;
    }
    cout<<"_________________________________________________________________\n";
}
void Menu::searchProductByID(Inventory &inventory) {
    cout<<"\n_______________________Search Product____________________________\n";
    int ID;
    cout<<"\nEnter product ID: ";
    cin>>ID;
    if (!inventory.searchProductByID(ID)) {
        cout<<"Product does not exist!"<<endl;
    }else {
        auto product= inventory.searchProductByID(ID);
        cout<<"Product ID exists! -> "<<product-> getName()<<endl;
    }
    cout<<"_________________________________________________________________\n";
}
void Menu::takeOrder(Inventory &inventory, vector<Order> &orders) {
    cout<<"\n===========================Place Order==============================\n";

    int orderID, productID, quantity;
    //A generated Order ID
    do {
        orderID = rand() % 900 + 100; // A 3-digit unique ID
    } while(idExists(orders, orderID));

    cout<<"Enter Product ID: \n";
    cin>>productID;
    auto product = inventory.searchProductByID(productID);
    if (!product) {
        cout<<"Product does not exist!"<<endl;
        return;
    }
    cout<<"Enter Quantity: \n";
    cin>>quantity;

    if (quantity <= 0) {
        cout<<"Invalid quantity!"<<endl;
        return;
    }
    //Stock Update
    product->reduceStock(quantity);
    orders.emplace_back(orderID, productID, quantity);

    cout<<"Order "<<orderID<<" placed successfully!"<<endl;
}
void Menu::viewOrder(vector<Order>& orders) {
    cout << "\n__________________________All Orders_____________________________" << endl;
    if (orders.empty()) {
        cout << "\nNo orders available.\n";
        return;
    }else{
        for (auto& order : orders) {
            order.displayOrder(); 
        }
    }
    cout << "\n_________________________________________________________________\n";
}
void Menu::sortByPrice(Inventory& inventory) {
    auto sortedProducts = inventory.sortByPrice();
    cout << "\n              Products sorted by price\n" << endl;
    for(const auto& product: sortedProducts){
        product->displayProduct();
        cout << "---------------------------------------------------------------------------------------------------------------------------------------" << endl;
    }
    
}
bool Menu::idExists(vector<Order>& orders, int id) {
    for(int i = 0; i < orders.size(); i++) {
        if(orders[i].getOrderID() == id) {
            return true;
        }
    }
    return false;
}
Inventory& Menu::fillInventory(Inventory& inventory) {
    TaxableProduct product1(1001,"Maize Meal 5kg",89.99,40,0.15);
    TaxableProduct product2(1002,"Sunflower Oil 2L",75.50,30,0.15);
    TaxableProduct product3(1003,"White Bread",14.99,60,0.0);
    TaxableProduct product4(1004,"Brown Bread",15.50,55,0.0);
    TaxableProduct product5(1005,"Milk 2L",32.99,45,0.0);
    TaxableProduct product6(1006,"Eggs 18 Pack",54.99,25,0.0);
    TaxableProduct product7(1007,"Rice 10kg",189.99,20,0.15);
    TaxableProduct product8(1008,"Sugar 2kg",45.99,50,0.15);
    TaxableProduct product9(1009,"Salt 1kg",9.99,80,0.15);
    TaxableProduct product10(1010,"Tea Bags 100s",39.99,35,0.15);
    TaxableProduct product11(1011,"Instant Coffee 200g",89.99,25,0.15);
    TaxableProduct product12(1012,"Canned Beans",13.50,70,0.15);
    TaxableProduct product13(1013,"Spaghetti 500g",12.99,60,0.15);
    TaxableProduct product14(1014,"Macaroni 500g",12.99,60,0.15);
    TaxableProduct product15(1015,"Frozen Chicken 2kg",119.99,30,0.15);
    TaxableProduct product16(1016,"Beef Mince 1kg",99.99,25,0.15);
    TaxableProduct product17(1017,"Boerewors 1kg",109.99,20,0.15);
    TaxableProduct product18(1018,"Cheddar Cheese 500g",65.99,30,0.15);
    TaxableProduct product19(1019,"Yoghurt 1kg",45.99,40,0.0);
    TaxableProduct product20(1020,"Butter 500g",59.99,25,0.15);
    TaxableProduct product21(1021,"Dishwashing Liquid",29.99,50,0.15);
    TaxableProduct product22(1022,"Laundry Powder 2kg",85.99,30,0.15);
    TaxableProduct product23(1023,"Toilet Paper 9 Pack",79.99,40,0.15);
    TaxableProduct product24(1024,"Paper Towels",24.99,45,0.15);
    TaxableProduct product25(1025,"Bath Soap 6 Pack",35.99,50,0.15);
    TaxableProduct product26(1026,"Shampoo 400ml",49.99,30,0.15);
    TaxableProduct product27(1027,"Toothpaste",19.99,60,0.15);
    TaxableProduct product28(1028,"Toothbrush",14.99,70,0.15);
    TaxableProduct product29(1029,"Hand Sanitizer",22.99,55,0.15);
    TaxableProduct product30(1030,"Body Lotion",39.99,35,0.15);
    TaxableProduct product31(1031,"Laptop Backpack",399.99,15,0.15);
    TaxableProduct product32(1032,"USB Flash Drive 32GB",129.99,25,0.15);
    TaxableProduct product33(1033,"Wireless Mouse",199.99,20,0.15);
    TaxableProduct product34(1034,"Keyboard",249.99,18,0.15);
    TaxableProduct product35(1035,"Phone Charger",149.99,30,0.15);
    TaxableProduct product36(1036,"Bluetooth Speaker",499.99,10,0.15);
    TaxableProduct product37(1037,"Headphones",299.99,12,0.15);
    TaxableProduct product38(1038,"LED Light Bulb",39.99,60,0.15);
    TaxableProduct product39(1039,"Extension Cable",89.99,25,0.15);
    TaxableProduct product40(1040,"Power Bank",299.99,20,0.15);
    TaxableProduct product41(1041,"Office Chair",1299.99,8,0.15);
    TaxableProduct product42(1042,"Study Desk",1599.99,5,0.15);
    TaxableProduct product43(1043,"Notebook Pack",59.99,50,0.15);
    TaxableProduct product44(1044,"Pens Pack",29.99,70,0.15);
    TaxableProduct product45(1045,"Highlighters",34.99,60,0.15);
    TaxableProduct product46(1046,"Calculator",199.99,20,0.15);
    TaxableProduct product47(1047,"Stapler",49.99,30,0.15);
    TaxableProduct product48(1048,"Printer Paper",89.99,40,0.15);
    TaxableProduct product49(1049,"Whiteboard Marker",24.99,50,0.15);
    TaxableProduct product50(1050,"Desk Lamp",299.99,15,0.15);
    DiscountedProduct product51(2001,"Apples 1kg",24.99,60,0.10);
    DiscountedProduct product52(2002,"Bananas 1kg",19.99,70,0.10);
    DiscountedProduct product53(2003,"Oranges 1kg",29.99,50,0.10);
    DiscountedProduct product54(2004,"Potatoes 2kg",39.99,40,0.10);
    DiscountedProduct product55(2005,"Onions 1kg",21.99,55,0.10);
    DiscountedProduct product56(2006,"Tomatoes 1kg",26.99,60,0.10);
    DiscountedProduct product57(2007,"Cabbage",18.99,35,0.10);
    DiscountedProduct product58(2008,"Carrots 1kg",19.99,50,0.10);
    DiscountedProduct product59(2009,"Green Beans",22.99,45,0.10);
    DiscountedProduct product60(2010,"Spinach",15.99,40,0.10);
    DiscountedProduct product61(2011,"Chicken Pieces 1kg",69.99,30,0.15);
    DiscountedProduct product62(2012,"Pork Chops 1kg",89.99,25,0.15);
    DiscountedProduct product63(2013,"Lamb Chops 1kg",139.99,20,0.15);
    DiscountedProduct product64(2014,"Sausages 1kg",79.99,35,0.15);
    DiscountedProduct product65(2015,"Frozen Chips 2kg",49.99,40,0.15);
    DiscountedProduct product66(2016,"Ice Cream 2L",59.99,30,0.15);
    DiscountedProduct product67(2017,"Chocolate Bar",12.99,80,0.10);
    DiscountedProduct product68(2018,"Biscuits Pack",19.99,60,0.10);
    DiscountedProduct product69(2019,"Soft Drink 2L",22.99,70,0.10);
    DiscountedProduct product70(2020,"Energy Drink",15.99,65,0.10);
    DiscountedProduct product71(2021,"T-Shirt",99.99,40,0.20);
    DiscountedProduct product72(2022,"Jeans",299.99,25,0.20);
    DiscountedProduct product73(2023,"Sneakers",499.99,20,0.20);
    DiscountedProduct product74(2024,"Jacket",699.99,15,0.20);
    DiscountedProduct product75(2025,"Socks Pack",59.99,50,0.15);
    DiscountedProduct product76(2026,"Cap",79.99,35,0.15);
    DiscountedProduct product77(2027,"Scarf",89.99,30,0.15);
    DiscountedProduct product78(2028,"Gloves",69.99,25,0.15);
    DiscountedProduct product79(2029,"Belt",119.99,20,0.15);
    DiscountedProduct product80(2030,"Sunglasses",149.99,18,0.15);
    DiscountedProduct product81(2031,"Notebook Laptop",5999.99,10,0.10);
    DiscountedProduct product82(2032,"Tablet",3499.99,12,0.10);
    DiscountedProduct product83(2033,"Smartphone",7999.99,8,0.10);
    DiscountedProduct product84(2034,"Smartwatch",2499.99,15,0.10);
    DiscountedProduct product85(2035,"Gaming Console",8999.99,5,0.10);
    DiscountedProduct product86(2036,"Router",999.99,20,0.10);
    DiscountedProduct product87(2037,"External HDD 1TB",1299.99,18,0.10);
    DiscountedProduct product88(2038,"Monitor 24 inch",2499.99,10,0.10);
    DiscountedProduct product89(2039,"Printer",1999.99,12,0.10);
    DiscountedProduct product90(2040,"Webcam",799.99,20,0.10);
    DiscountedProduct product91(2041,"Cooking Pot Set",899.99,15,0.15);
    DiscountedProduct product92(2042,"Frying Pan",299.99,20,0.15);
    DiscountedProduct product93(2043,"Kettle",399.99,18,0.15);
    DiscountedProduct product94(2044,"Microwave",1499.99,10,0.15);
    DiscountedProduct product95(2045,"Toaster",499.99,12,0.15);
    DiscountedProduct product96(2046,"Blender",699.99,14,0.15);
    DiscountedProduct product97(2047,"Vacuum Cleaner",1999.99,8,0.15);
    DiscountedProduct product98(2048,"Iron",599.99,16,0.15);
    DiscountedProduct product99(2049,"Electric Fan",899.99,10,0.15);
    DiscountedProduct product100(2050,"Heater",1299.99,9,0.15);
    inventory.addProduct(make_shared<TaxableProduct>(product1));
    inventory.addProduct(make_shared<TaxableProduct>(product2));
    inventory.addProduct(make_shared<TaxableProduct>(product3));
    inventory.addProduct(make_shared<TaxableProduct>(product4));
    inventory.addProduct(make_shared<TaxableProduct>(product5));
    inventory.addProduct(make_shared<TaxableProduct>(product6));
    inventory.addProduct(make_shared<TaxableProduct>(product7));
    inventory.addProduct(make_shared<TaxableProduct>(product8));
    inventory.addProduct(make_shared<TaxableProduct>(product9));
    inventory.addProduct(make_shared<TaxableProduct>(product10));
    inventory.addProduct(make_shared<TaxableProduct>(product11));
    inventory.addProduct(make_shared<TaxableProduct>(product12));
    inventory.addProduct(make_shared<TaxableProduct>(product13));
    inventory.addProduct(make_shared<TaxableProduct>(product14));
    inventory.addProduct(make_shared<TaxableProduct>(product15));
    inventory.addProduct(make_shared<TaxableProduct>(product16));
    inventory.addProduct(make_shared<TaxableProduct>(product17));
    inventory.addProduct(make_shared<TaxableProduct>(product18));
    inventory.addProduct(make_shared<TaxableProduct>(product19));
    inventory.addProduct(make_shared<TaxableProduct>(product20));
    inventory.addProduct(make_shared<TaxableProduct>(product21));
    inventory.addProduct(make_shared<TaxableProduct>(product22));
    inventory.addProduct(make_shared<TaxableProduct>(product23));
    inventory.addProduct(make_shared<TaxableProduct>(product24));
    inventory.addProduct(make_shared<TaxableProduct>(product25));
    inventory.addProduct(make_shared<TaxableProduct>(product26));
    inventory.addProduct(make_shared<TaxableProduct>(product27));
    inventory.addProduct(make_shared<TaxableProduct>(product28));
    inventory.addProduct(make_shared<TaxableProduct>(product29));
    inventory.addProduct(make_shared<TaxableProduct>(product30));
    inventory.addProduct(make_shared<TaxableProduct>(product31));
    inventory.addProduct(make_shared<TaxableProduct>(product32));
    inventory.addProduct(make_shared<TaxableProduct>(product33));
    inventory.addProduct(make_shared<TaxableProduct>(product34));
    inventory.addProduct(make_shared<TaxableProduct>(product35));
    inventory.addProduct(make_shared<TaxableProduct>(product36));
    inventory.addProduct(make_shared<TaxableProduct>(product37));
    inventory.addProduct(make_shared<TaxableProduct>(product38));
    inventory.addProduct(make_shared<TaxableProduct>(product39));
    inventory.addProduct(make_shared<TaxableProduct>(product40));
    inventory.addProduct(make_shared<TaxableProduct>(product41));
    inventory.addProduct(make_shared<TaxableProduct>(product42));
    inventory.addProduct(make_shared<TaxableProduct>(product43));
    inventory.addProduct(make_shared<TaxableProduct>(product44));
    inventory.addProduct(make_shared<TaxableProduct>(product45));
    inventory.addProduct(make_shared<TaxableProduct>(product46));
    inventory.addProduct(make_shared<TaxableProduct>(product47));
    inventory.addProduct(make_shared<TaxableProduct>(product48));
    inventory.addProduct(make_shared<TaxableProduct>(product49));
    inventory.addProduct(make_shared<TaxableProduct>(product50));
    inventory.addProduct(make_shared<DiscountedProduct>(product51));
    inventory.addProduct(make_shared<DiscountedProduct>(product52));
    inventory.addProduct(make_shared<DiscountedProduct>(product53));
    inventory.addProduct(make_shared<DiscountedProduct>(product54));
    inventory.addProduct(make_shared<DiscountedProduct>(product55));
    inventory.addProduct(make_shared<DiscountedProduct>(product56));
    inventory.addProduct(make_shared<DiscountedProduct>(product57));
    inventory.addProduct(make_shared<DiscountedProduct>(product58));
    inventory.addProduct(make_shared<DiscountedProduct>(product59));
    inventory.addProduct(make_shared<DiscountedProduct>(product60));
    inventory.addProduct(make_shared<DiscountedProduct>(product61));
    inventory.addProduct(make_shared<DiscountedProduct>(product62));
    inventory.addProduct(make_shared<DiscountedProduct>(product63));
    inventory.addProduct(make_shared<DiscountedProduct>(product64));
    inventory.addProduct(make_shared<DiscountedProduct>(product65));
    inventory.addProduct(make_shared<DiscountedProduct>(product66));
    inventory.addProduct(make_shared<DiscountedProduct>(product67));
    inventory.addProduct(make_shared<DiscountedProduct>(product68));
    inventory.addProduct(make_shared<DiscountedProduct>(product69));
    inventory.addProduct(make_shared<DiscountedProduct>(product70));
    inventory.addProduct(make_shared<DiscountedProduct>(product71));
    inventory.addProduct(make_shared<DiscountedProduct>(product72));
    inventory.addProduct(make_shared<DiscountedProduct>(product73));
    inventory.addProduct(make_shared<DiscountedProduct>(product74));
    inventory.addProduct(make_shared<DiscountedProduct>(product75));
    inventory.addProduct(make_shared<DiscountedProduct>(product76));
    inventory.addProduct(make_shared<DiscountedProduct>(product77));
    inventory.addProduct(make_shared<DiscountedProduct>(product78));
    inventory.addProduct(make_shared<DiscountedProduct>(product79));
    inventory.addProduct(make_shared<DiscountedProduct>(product80));
    inventory.addProduct(make_shared<DiscountedProduct>(product81));
    inventory.addProduct(make_shared<DiscountedProduct>(product82));
    inventory.addProduct(make_shared<DiscountedProduct>(product83));
    inventory.addProduct(make_shared<DiscountedProduct>(product84));
    inventory.addProduct(make_shared<DiscountedProduct>(product85));
    inventory.addProduct(make_shared<DiscountedProduct>(product86));
    inventory.addProduct(make_shared<DiscountedProduct>(product87));
    inventory.addProduct(make_shared<DiscountedProduct>(product88));
    inventory.addProduct(make_shared<DiscountedProduct>(product89));
    inventory.addProduct(make_shared<DiscountedProduct>(product90));
    inventory.addProduct(make_shared<DiscountedProduct>(product91));
    inventory.addProduct(make_shared<DiscountedProduct>(product92));
    inventory.addProduct(make_shared<DiscountedProduct>(product93));
    inventory.addProduct(make_shared<DiscountedProduct>(product94));
    inventory.addProduct(make_shared<DiscountedProduct>(product95));
    inventory.addProduct(make_shared<DiscountedProduct>(product96));
    inventory.addProduct(make_shared<DiscountedProduct>(product97));
    inventory.addProduct(make_shared<DiscountedProduct>(product98));
    inventory.addProduct(make_shared<DiscountedProduct>(product99));
    inventory.addProduct(make_shared<DiscountedProduct>(product100));
    return inventory;
}
void Menu::setOrders(vector<vector<Order>>& orders){
    vector<Order> customer1;
    customer1.emplace_back(772,1001,2);
    customer1.emplace_back(323,1005,1);
    vector<Order> customer2;
    customer2.emplace_back(444,1007,1);
    vector<Order> customer3;
    customer3.emplace_back(941,1010,3);
    customer3.emplace_back(313,1012,5);
    vector<Order> customer4;
    customer4.emplace_back(221,1021,2);
    vector<Order> customer5;
    customer5.emplace_back(101,1033,1);
    customer5.emplace_back(492,1035,2);
    vector<Order> customer6;
    customer6.emplace_back(132,1043,4);
    vector<Order> customer7;
    customer7.emplace_back(231,5001,3);
    customer7.emplace_back(322,2002,2);
    vector<Order> customer8;
    customer8.emplace_back(161,2011,200);
    vector<Order> customer9;
    customer9.emplace_back(231,2021,2);
    customer9.emplace_back(808,2075,3);
    vector<Order> customer10;
    customer10.emplace_back(333,2031,1);
    vector<Order> customer11;
    customer11.emplace_back(720,2041,1);
    customer11.emplace_back(529,2043,1);
    vector<Order> customer12;
    customer12.emplace_back(900,1003,6);
    customer12.emplace_back(712,1008,2);
    vector<Order> customer13;
    customer13.emplace_back(879,1115,2);
    customer13.emplace_back(121,1018,1);
    
    orders.push_back(customer1);
    orders.push_back(customer2);
    orders.push_back(customer3);
    orders.push_back(customer4);
    orders.push_back(customer5);
    orders.push_back(customer6);
    orders.push_back(customer7);
    orders.push_back(customer8);
    orders.push_back(customer9);
    orders.push_back(customer10);
    orders.push_back(customer11);
    orders.push_back(customer12);
    //orders.push_back(customer13);

}
void Menu::CustomerInterface(Inventory& inventory,vector<vector<Order>>& orders) {
    int choice2, choice3;
    vector<Order> CustomerOrder;
    while (true) {
        cout << "\n============= CUSTOMER MENU =============\n";
        cout << "1. View Products\n";
        cout << "2. Order Product\n";
        cout << "3. View Order\n";
        cout << "4. Search Product by ID\n";
        cout << "5. Log Out\n";
        cout << "Enter Choice: ";
        cin >> choice2;
        if (choice2 == 1) {
            displayProduct(inventory);
        }
        else if (choice2 == 2) {
            displayProduct(inventory);
            cout << "Choose from the product IDs provided above\n";
            takeOrder(inventory, CustomerOrder);
        }
        else if (choice2 == 3) {
            viewOrder(CustomerOrder);
            cout << "1. Submit Order\n";
            cout << "2. Add Another Item\n";
            cout << "3. Remove Item\n";
            cout << "4. Cancel Order\n";
            cout << "Enter Choice: ";
            cin >> choice3;
            if (choice3 == 1) {
                orders.push_back(CustomerOrder);
                CustomerOrder.clear();
                cout << "Order submitted successfully.\n";
            }
            else if (choice3 == 2) {
                takeOrder(inventory, CustomerOrder);
            }
            else if (choice3 == 3) {
                if (!CustomerOrder.empty()) {
                    int id;
                    cout << "Enter Product ID to remove: ";
                    cin >> id;
                    bool found = false;
                    for (auto it = CustomerOrder.begin();
                         it != CustomerOrder.end(); ++it) {
                        if (it->getProductID() == id) {
                            CustomerOrder.erase(it);
                            cout << "Item removed successfully.\n";
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        cout << "Product not found.\n";
                    }
                } else {
                    cout << "No orders available.\n";
                }
            }
            else if (choice3 == 4) {
                CustomerOrder.clear();
                cout << "Order cancelled.\n";
            }
        }
        else if (choice2 == 4) {
            searchProductByID(inventory);
        }
        else if (choice2 == 5) {
            cout << "Logging out...\n";
            break; // returns to main menu
        }
        else {
            cout << "Invalid choice.\n";
        }
    }
}
void Menu::ManagementInterface(Inventory& inventory,vector<vector<Order>>& orders) {
    int choice2;
    while (true) {
        cout << "\n================ MANAGEMENT MENU ================\n";
        cout << "1. Add Product\n";
        cout << "2. Remove Product\n";
        cout << "3. Display Products\n";
        cout << "4. Restock Product\n";
        cout << "5. Search Product by ID\n";
        cout << "6. Sort Products by Price\n";
        cout << "7. Process Customer Orders\n";
        cout << "8. Log Out\n";
        cout << "Enter Choice: ";
        cin >> choice2;
        if (choice2 == 1) {
            addNewProduct(inventory);
        }
        else if (choice2 == 2) {
            removeProduct(inventory);
        }
        else if (choice2 == 3) {
            displayProduct(inventory);
        }
        else if (choice2 == 4) {
            restockProduct(inventory);
        }
        else if (choice2 == 5) {
            searchProductByID(inventory);
        }
        else if (choice2 == 6) {
            sortByPrice(inventory);
        }
        else if (choice2 == 7) {
            processOrder(inventory, orders);
            cout << "All orders processed successfully.\n";
        }
        else if (choice2 == 8) {
            cout << "Logging out...\n";
            break; // returns to main menu
        }
        else {
            cout << "Invalid choice.\n";
        }
    }
}