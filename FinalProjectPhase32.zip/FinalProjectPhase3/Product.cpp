#include "Product.h"
#include <stdexcept>
using namespace std;
Product::Product(int productID, const string& name, double price, int stock)
    : productID(productID), stock(stock), name(name), price(price){
    if (price < 0.0)
        throw invalid_argument("Price cannot be negative.");
    if (stock < 0)
        throw invalid_argument("Stock cannot be negative.");
}
int Product::getStock() const {return stock;}
double Product::getPrice() const {return price;}
int Product::getProductID() const {return productID;}
const string& Product::getName() const {return name;}
void Product::displayProduct() const {
    cout << "ID: " << productID
        << "| Name: " << name
        << "| Price: R" << price
        << "| Stock: " << stock;
}
void Product::reduceStock(int amount) {
    if (amount <= 0)
        throw invalid_argument("Reduction amount must be positive.");
    if (amount > stock)
        throw runtime_error("Not enough stock available.");
    stock -= amount;
}
void Product::increaseStock(int amount) {
    if (amount <= 0)
        throw invalid_argument("Increase amount must be positive.");
    stock += amount;
}
Product::~Product() {}