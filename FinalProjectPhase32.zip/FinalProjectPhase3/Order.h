#include <string>
using namespace std;
#ifndef ORDER_H
#define ORDER_H
enum status {PENDING, SUCCESS, FAILED};
enum reason {PRODUCT_NOT_FOUND,INSUFFICIENT_STOCK,NONE};
class Order {
private:
    int orderID;
    int productID;
    int quantity;
protected:
    status orderStatus;
    reason FailedReason;
public:
    Order(int orderID,int productID,int quantity);
    status getOrderStatus() const;
    void setOrderStatus(status newStatus);
    reason getFailedReason() const;
    void setFailedReason(reason newReason);
    int getProductID() const;
    int getQuantity() const;
    int getOrderID() const;
    void displayOrder() const;
    string statusToString(status newStatus) const;
    string reasonToString(reason newReason) const;
};
#endif